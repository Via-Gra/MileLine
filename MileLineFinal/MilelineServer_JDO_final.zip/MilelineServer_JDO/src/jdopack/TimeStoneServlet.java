package jdopack;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.Key;
import com.google.gson.Gson;

@SuppressWarnings("serial")
public class TimeStoneServlet extends HttpServlet {
	PersistenceManager pm = null; // singleton v souboru PMF.java
	Gson gson = new Gson();

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		try {
			pm = PMF.get().getPersistenceManager(); // singleton v souboru
													// PMF.java

			if (req.getParameter("kod") == null) {
				if (req.getParameter("typ") != null) {
					getAllTimeStonesByType(req, resp);
				} else {
					getAllTimeStones(req, resp);
				}

			} else {
				getTimeStoneByKod(req, resp);
			}

		} finally {
			resp.getWriter().flush();
			resp.getWriter().close();
			pm.close();
		}
	}

	private void getTimeStoneByKod(HttpServletRequest req,
			HttpServletResponse resp) throws IOException {

		String kodStonu = req.getParameter("kod");

		Key k = TimeStone.creatKey(kodStonu);// vygeneruje kl��
		TimeStone nalezenyTimeStone = pm.getObjectById(TimeStone.class, k);
		resp.getWriter().append(gson.toJson(nalezenyTimeStone));
	}

	@SuppressWarnings("unchecked")
	private void getAllTimeStonesByType(HttpServletRequest req,
			HttpServletResponse resp) throws IOException {
		String typ = req.getParameter("typ").toUpperCase();
		List<TimeStone> list = null;

		Query query = pm.newQuery(TimeStone.class);
		query.setFilter("(typ == myParam)");
		query.declareParameters("String myParam");
		list = (List<TimeStone>) query.execute(typ);

		resp.getWriter().append(gson.toJson(list));
	}

	@SuppressWarnings("unchecked")
	private void getAllTimeStones(HttpServletRequest req,
			HttpServletResponse resp) throws IOException {
		List<TimeStone> list = null;

		list = (List<TimeStone>) pm.newQuery(TimeStone.class).execute();

		resp.getWriter().append(gson.toJson(list));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		pm = PMF.get().getPersistenceManager();
		String nazev = req.getParameter("nazev");
		String kod = req.getParameter("kod");
		String kredity = req.getParameter("kredity");
		Typ typ = Typ.fromString(req.getParameter("typ"));
		String zacatek = req.getParameter("zacatek");
		String konec = req.getParameter("konec");
		String sudost = req.getParameter("sudost");

		if (typ != null) {
			if (typ.equals(Typ.SEMESTR)) {
				if (nazev != null && zacatek != null && konec != null
						&& sudost != null && !nazev.isEmpty() && !zacatek.isEmpty() && !konec.isEmpty() && !sudost.isEmpty()) {
					createSemestrTimeStone(nazev, zacatek, konec, sudost, typ,
							resp);
				} else {
					resp.getWriter()
							.println(
									"Some requested attributes for semestr are missing.");
				}
			} else if (typ.equals(Typ.PREDMET)) {
				if (nazev != null && kod != null && !nazev.isEmpty() && !kod.isEmpty()) {
					createPredmetTimeStone(nazev, kod, typ, kredity, resp);
				} else {
					resp.getWriter()
							.println(
									"Some requested attributes for subject are missing.");
				}
			}
		} else {
			resp.getWriter().println("Type of timestone is not specified.");
		}

		pm.close();
	}

	private void createSemestrTimeStone(String nazev, String zacatek,
			String konec, String sudost, Typ typ, HttpServletResponse resp)
			throws IOException {

		Date zacatekD = new Date();
		Date konecD = new Date();
		Calendar c = Calendar.getInstance();
		Long t = null;
		try {
			t = Long.parseLong(zacatek);
			zacatekD.setTime(t);
			t = Long.parseLong(konec);
			konecD.setTime(t);
			c.setTime(zacatekD);

			nazev += (c.get(Calendar.WEEK_OF_YEAR) > 20) ? "_Zimni" : "_Letni";
			String kod = (c.get(Calendar.WEEK_OF_YEAR) > 20) ? (nazev + "Zimni" + c
					.get(Calendar.YEAR)) : (nazev + "Letni" + c
					.get(Calendar.YEAR));
			boolean sud = Boolean.parseBoolean(sudost);

			TimeStone ts = new TimeStone(nazev, kod, typ, zacatekD, konecD, sud);

			pm.makePersistent(ts);

		} catch (Exception e) {
			resp.getWriter().println("Something went wrong.");
			// e.printStackTrace();
		} finally {
			resp.getWriter().println("Semestr has been successfully created.");
		}
	}

	private void createPredmetTimeStone(String nazev, String kod, Typ typ,
			String kredity, HttpServletResponse resp) throws IOException {
		TimeStone ts = new TimeStone(nazev, kod, typ);
		if (kredity != null) {
			ts.setPocetKreditu(Integer.valueOf(kredity));
		}

		pm.makePersistent(ts);
		resp.getWriter().println("Subject successfully created.");
	}
}
