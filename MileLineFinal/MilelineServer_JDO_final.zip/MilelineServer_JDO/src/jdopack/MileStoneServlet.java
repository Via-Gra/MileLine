package jdopack;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.Key;
import com.google.gson.Gson;

@SuppressWarnings("serial")
public class MileStoneServlet extends HttpServlet {
	PersistenceManager pm = null;
	Gson gson = new Gson();

	@SuppressWarnings("unchecked")
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if (req.getParameter("kod") != null && !req.getParameter("kod").isEmpty()) {
			try {
				pm = PMF.get().getPersistenceManager();
				getAllMileStonesByTimeStone(req, resp);
			} finally {
				resp.getWriter().flush();
				resp.getWriter().close();
				pm.close();
			}
		}else{
			pm = PMF.get().getPersistenceManager();
			List<MileStone> list = null;

			list = (List<MileStone>) pm.newQuery(MileStone.class).execute();

			resp.getWriter().append(gson.toJson(list));
		}
	}

	private void getAllMileStonesByTimeStone(HttpServletRequest req,
			HttpServletResponse resp) throws IOException {

		String kodStonu = req.getParameter("kod");
		Key k = TimeStone.creatKey(kodStonu);
		TimeStone nalezenyTimeStone = pm.getObjectById(TimeStone.class, k);
		List<MileStone> list = null;
		list = nalezenyTimeStone.getMileStony();

		resp.getWriter().append(gson.toJson(list));
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		pm = PMF.get().getPersistenceManager();
		String nazev = req.getParameter("nazev");
		String kod = req.getParameter("kod");
		String datum = req.getParameter("datum");
		String poznamka = req.getParameter("poznamka");

		try {
			if (kod != null && !kod.isEmpty()) {
				if (datum != null && nazev != null && kod != null && !datum.isEmpty() && !nazev.isEmpty() && !kod.isEmpty()) {
					Date dat = new Date();
					dat.setTime(Long.parseLong(datum));
					Key k = TimeStone.creatKey(kod);
					TimeStone stone = pm.getObjectById(TimeStone.class, k);
					if (stone != null) {
						stone.addMileStone(new MileStone(kod, stone
								.getPocetMileStonu() + 1, nazev, dat, poznamka));
						pm.makePersistent(stone);
						resp.getWriter().println(
								"Milestone has been successfully created.");
					} else {
						resp.getWriter()
								.println(
										"Subject/Semester that you wish to update not found.");
					}
				} else {
					resp.getWriter().println(
							"Some requested attributes are missing.");
				}
			} else {
				resp.getWriter().println("Subject/Semester code is not specified.");
			}
		} catch (Exception e) {
			resp.getWriter().println("Something went wrong.");
		} finally {
			pm.close();
		}
	}
}
