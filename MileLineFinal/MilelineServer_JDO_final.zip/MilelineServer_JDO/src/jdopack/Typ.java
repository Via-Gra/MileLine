package jdopack;

import java.io.Serializable;

public enum Typ implements Serializable {
	PREDMET, SEMESTR;

	public static Typ fromString(String text) {
		if (text != null) {
			for (Typ b : Typ.values()) {
				if (text.equalsIgnoreCase(b.name())) {
					return b;
				}
			}
		}
		return null;
	}
}
