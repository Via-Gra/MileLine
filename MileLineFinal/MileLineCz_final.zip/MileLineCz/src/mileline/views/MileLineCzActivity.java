package mileline.views;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import mileline.diskmanager.HardFile;
import mileline.model.MileStone;
import mileline.model.TimeStone;
import mileline.model.Typ;
import mileline.model.ViewHolderMileStonu;
import mileline.model.ViewHolderTimeStonu;
import mileline.tasks.CreateMileStoneListener;
import mileline.tasks.CreateTimeStoneListener;
import mileline.tasks.RefreshMileStoneListener;
import mileline.tasks.RefreshTimeStoneListener;
import mileline.tasks.SeznamMileStonuAdapter;
import mileline.tasks.SeznamTimeStonuAdapter;
import mileline.tasks.TrackListener;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

public class MileLineCzActivity extends Activity {
	private TextView timeStoneText;
	private static MileLineCzActivity self;
	private int soucasnyView;

	int counter = 0;
	
	// HLAVNI OBRAZOVKA
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		self = this;
		// requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);
		
		
		counter = 0;
		RelativeLayout layout = (RelativeLayout) findViewById(R.id.lajna);
		
        
	    Calendar c = Calendar.getInstance();
	    c.set(2011,9-1,19); //podle toho prvn�ho dne semestru
	    int den1 = c.get(Calendar.DAY_OF_YEAR);
	    
	    //Date dnes = new Date();
	    Date dnes = new Date (2011,12-1,3);
	    c.setTime(dnes);
	    int today = c.get(Calendar.DAY_OF_YEAR);
	    
	    int posun = today-den1;
	    
	    
	    /*Date d = new Date (2011,9-1,20); //datum, ktery chci umistit na lajnu
	 	Button btn = new Button(this);
	 	tlacitko(den1,today,d,c,btn);		 	
	 	layout.addView(btn);
	 	
	 	d = new Date (2011,11-1,23); //datum, ktery chci umistit na lajnu
	 	btn = new Button(this);
	 	tlacitko(den1,today,d,c,btn);		 	
	 	layout.addView(btn);*/
	 
/*	 	if(posun<45){
	 	layout.setX(-posun*25+30);	
	 	} else {
	 	layout.setX(-1200);	
	 	}*/

		timeStoneText = (TextView) findViewById(R.id.deadLineTextMain);
		// HardFile hf = new HardFile("all"+typ.toString().PREDMET);//pudePryc
		// timeStoneText.setText("loaded" + (String) hf.loadData());
		Button refreshButt = (Button) findViewById(R.id.refreshButtonMain);

		ListView seznamStonu = (ListView) findViewById(R.id.listStoneMain);

		//ArrayList<TimeStone> stony = new ArrayList<TimeStone>();
		HardFile hf = new HardFile("track" + Typ.PREDMET);
		ArrayList<TimeStone> stony = (ArrayList<TimeStone>) hf
				.loadDataArray();

		ArrayList<MileStone> milestony = gimmeMileStones (stony);
	
		
		milestony = SeznamMileStonuAdapter.sortByDate(milestony);
		
    for(int i =0; i < milestony.size();i++){
    	MileStone m = milestony.get(i);
    	Date dat = m.getDatum();
    	
    	Date d = new Date (dat.getYear(),dat.getMonth(),dat.getDay()); //datum, ktery chci umistit na lajnu
	 	Button btn = new Button(this);
	 	c.setTime(new Date());
	 	tlacitko(den1,today,d,c,btn);		 	
	 	layout.addView(btn);	
	    }
    
  /*  Date d = new Date (2011,9-1,20); //datum, ktery chci umistit na lajnu
 	Button btn = new Button(this);
 	tlacitko(den1,today,d,c,btn);		 	
 	layout.addView(btn);*/
	    

		// stony = (ArrayList<TimeStone>) hf.loadDataArray();
		seznamStonu.setAdapter(new SeznamMileStonuAdapter(this, stony));

		seznamStonu.setTextFilterEnabled(true);

		seznamStonu.setOnItemClickListener(new MileStoneClickListener() );

		refreshButt.setOnClickListener(new RefreshMileStoneListener(refreshButt,seznamStonu));
	}

	private ArrayList<MileStone> gimmeMileStones(ArrayList<TimeStone> stony) {
		ArrayList<MileStone> vysledek = new ArrayList<MileStone>();
		for (TimeStone timestone : stony){
			merge(vysledek,timestone.getMileStony());
		}
		return vysledek;
	}

	public static MileLineCzActivity getSelf() {
		return self;
	}

	@Override
	public void setContentView(int view) {
		super.setContentView(view);
		soucasnyView = view;
	}

	public int getContentView() {
		return soucasnyView;
	}

	// MENU
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		//inflater.inflate(R.menu.editable, menu);
		//inflater.inflate(R.menu.refreshable, menu);
		return true;
	}
	


	// MENU - AKCE
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.optionText:
			setContentView(R.layout.options);
			break;
		case R.id.mySubjectText:
			showMyTimeStoneHandler(null, Typ.PREDMET);
			break;
		case R.id.mySemestrText:
			showMyTimeStoneHandler(null, Typ.SEMESTR);
			break;
		case R.id.aboutText:
			setContentView(R.layout.about);
			break;
		case R.id.exitText:
			moveTaskToBack(true);
			break;
			
		case R.id.menu_refresh:
			setContentView(R.layout.options);
			break;
		case R.id.menu_edit:
			setContentView(R.layout.options);
			break;
		case R.id.menu_delete:
			setContentView(R.layout.options);
			break;
		}
		return true;
	}

	// back button
	@Override
	// http://stackoverflow.com/questions/2000102/android-override-back-button-to-act-like-home-button
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		// zde jsou vypsane vsechny tlacitka
		// http://developer.android.com/reference/android/view/KeyEvent.html
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// zde vlozit akci kterou chceme vykonat nap�:
			//
			if (getContentView() == R.layout.main)
				moveTaskToBack(true);
			else
				mainClickHandler(null);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	// MAIN SCREEN
	public void mainClickHandler(View v) {
		if (v != null)
			shodKlavesnici(v);

		// if (((Button) v).isPressed()) {
		onCreate(null);
		// }
	}

	// PREHLED VSECH PREDMETU
	public void addSubjectHandler(View v) {
		addTimeStoneHandler(v, Typ.PREDMET);
	}

	// PREHLED VSECH SEMESTRU
	public void addSemestrHandler(View v) {
		addTimeStoneHandler(v, Typ.SEMESTR);
	}

	// PREHLED VSECH TIMESTONU
	public void addTimeStoneHandler(View v, Typ typ) {

		setContentView(R.layout.all_timestones);
		if (typ.equals(Typ.PREDMET))
			((TextView) findViewById(R.id.all_timestones_typAllTymeStones))
					.setText(R.string.all_subjects);
		else if (typ.equals(Typ.SEMESTR))
			((TextView) findViewById(R.id.all_timestones_typAllTymeStones))
					.setText(R.string.all_semesters);

		Button refreshBut = ((Button) findViewById(R.id.refreshButtonAllTymeStones));

		ListView seznamMileStonu = (ListView) findViewById(R.id.listStone);

		refreshBut.setOnClickListener(new RefreshTimeStoneListener(refreshBut,
				seznamMileStonu, typ));

		HardFile hf = new HardFile("all" + typ.toString());
		ArrayList<TimeStone> allStones = (ArrayList<TimeStone>) hf
				.loadDataArray();
		hf = new HardFile("track" + typ.toString());
		ArrayList<TimeStone> myStones = (ArrayList<TimeStone>) hf
				.loadDataArray();
		seznamMileStonu.setAdapter(new SeznamTimeStonuAdapter(this, allStones,
				myStones));
		/*
		 * if (((ViewHolderTimeStonu) view.getTag()).isMy)
		 * nazev.setText(vybrany.getNazev() + " zapsano");
		 */
		seznamMileStonu.setTextFilterEnabled(true);

		seznamMileStonu
				.setOnItemClickListener(new TimeStoneClickListener("all"));
	}

	// PREHLED ULOZENEJCH PREDMETU
	public void showMySubjectsHandler(View v) {
		showMyTimeStoneHandler(v, Typ.PREDMET);
	}

	// PREHLED ULOZENEJCH SEMESTRU
	public void showMySemestrHandler(View v) {
		showMyTimeStoneHandler(v, Typ.SEMESTR);
	}

	// PREHLED ULOZENEJCH TIMESTONU
	public void showMyTimeStoneHandler(View v, Typ typ) {

		setContentView(R.layout.my_timestones);

		if (typ.equals(Typ.PREDMET))
			((TextView) findViewById(R.id.my_timestones_typMyTimeStones))
					.setText(R.string.my_subjects);
		else if (typ.equals(Typ.SEMESTR))
			((TextView) findViewById(R.id.my_timestones_typMyTimeStones))
					.setText(R.string.my_semesters);
		HardFile hf = new HardFile("track" + typ.toString());
		ListView seznamStonu = (ListView) findViewById(R.id.listStoneMyTimeStones);

		ArrayList<TimeStone> stony = (ArrayList<TimeStone>) hf.loadDataArray();
		seznamStonu.setAdapter(new SeznamTimeStonuAdapter(this, stony, null));

		seznamStonu.setTextFilterEnabled(true);

		seznamStonu.setOnItemClickListener(new TimeStoneClickListener("my"));
	}
	// ZOBRAZENI KONKRETNIHO MILESTONE
		class MileStoneClickListener implements OnItemClickListener {
			MileStone vybrany;
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {

			setContentView(R.layout.milestone);
			vybrany = (MileStone) (((ViewHolderMileStonu) view.getTag()).object);
			Date date = vybrany.getDatum();
			((TextView) findViewById(R.id.nadpisMileStone)).setText(vybrany.getNazev());
			((TextView) findViewById(R.id.predmetMileStone)).setText("");
			((TextView) findViewById(R.id.datumMileStone)).setText(date.getDay() + ". " + (date.getMonth()+1) + ". "
					+ (date.getYear()+1900) + " " + date.getHours() + ":"
					+ date.getMinutes());
			((TextView) findViewById(R.id.popisekMileStone)).setText(vybrany.getPoznamka());
			}
		}
	// ZOBRAZENI KONKRETNIHO TIMESTONE
	class TimeStoneClickListener implements OnItemClickListener {
		private String back;
		private TimeStone vybrany;

		public TimeStoneClickListener(String from) {
			back = from;
		}

		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			setContentView(R.layout.timestone);
			vybrany = (TimeStone) (((ViewHolderTimeStonu) view.getTag()).object);
			((TextView) findViewById(R.id.nadpisTimeStone)).setText(vybrany
					.getNazev());
			((TextView) findViewById(R.id.kodTimeStone)).setText(vybrany
					.getKod());
			((TextView) findViewById(R.id.kredityTimeStone)).setText(""
					+ vybrany.getPocetKreditu());
			Button createTimeStone = (Button) findViewById(R.id.createMileStoneButtonTimeStone);
			createTimeStone.setOnClickListener(new CreateMileStoneClickListener(vybrany));
			
			Button editTimeStone = (Button) findViewById(R.id.editButtonTimeStone);//(Button) findViewById(R.id.deleteButtonTimeStone);
			editTimeStone.setOnClickListener(new EditMileStoneClickListener(vybrany));
			
			((Button) findViewById(R.id.trackButtonTimeStone))
					.setOnClickListener(new TrackListener(vybrany,
							(Button) findViewById(R.id.trackButtonTimeStone),
							(TextView) findViewById(R.id.zapsanyTimeStone),
							createTimeStone));

			((Button) findViewById(R.id.backButtonTimeStone))
					.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							if (back.equals("my"))
								showMyTimeStoneHandler(v, vybrany.getTyp());
							else
								addTimeStoneHandler(v, vybrany.getTyp());
						}
					});
			HardFile hf = new HardFile("track" + vybrany.getTyp().toString());
			ArrayList<TimeStone> tsArray = (ArrayList<TimeStone>) hf
					.loadDataArray();
			boolean contains = false;
			for (TimeStone ts : tsArray) {
				if (ts.getKod().equals(vybrany.getKod())) {
					contains = true;
					break;
				}
			}
			if (!contains) {
				((Button) findViewById(R.id.trackButtonTimeStone))
						.setText((R.string.start_track));
				((TextView) findViewById(R.id.zapsanyTimeStone))
						.setText(R.string.nezapsany);
				createTimeStone.setVisibility(View.GONE);

			} else {
				((Button) findViewById(R.id.trackButtonTimeStone))
						.setText(R.string.stop_track);
				((TextView) findViewById(R.id.zapsanyTimeStone))
						.setText(R.string.zapsany);
				createTimeStone.setVisibility(View.VISIBLE);
			}
		}

	}

	// EDITACE TimeStonu
		class EditMileStoneClickListener implements OnClickListener {
			private TimeStone otec;

			public EditMileStoneClickListener(TimeStone otec) {
				this.otec = otec;
			}

			public void onClick(View v) {
				createSubjectHandler(v, otec.getNazev(), otec.getKod(), otec.getPocetKreditu());
			}
			}
		
		
	// VYTVORENI MILESTONU
	class CreateMileStoneClickListener implements OnClickListener {
		private TimeStone otec;

		public CreateMileStoneClickListener(TimeStone otec) {
			this.otec = otec;
		}

		public void onClick(View v) {
			setContentView(R.layout.create_milestone);
			
			ukazKlavesnici();
			
			
			TextView nadpis = ((TextView) findViewById(R.id.nadpisCreateMileStone));
			nadpis.setText(nadpis.getText().toString()+" of " + otec.getNazev());
			((EditText) findViewById(R.id.nazev_outCreateMileStone)).requestFocus();
			
			// display the current date
			fillActualDate ();
			cil = R.id.dateTextCreateMileStone;
			updateDisplay();

			((Button) findViewById(R.id.dateButtonCreateMileStone))
					.setOnClickListener(new View.OnClickListener() {
						public void onClick(View v) {
							cil = R.id.dateTextCreateMileStone;
							showDialog(TIME_DIALOG_ID);
							showDialog(DATE_DIALOG_ID);
						}
					});
			((Button) findViewById(R.id.createButtonCreateMileStoner)).setOnClickListener(new CreateMileStoneListener( (EditText) findViewById(R.id.nazev_outCreateMileStone), ((EditText) findViewById(R.id.poznamka_outCreateMileStone)), ((TextView) findViewById(R.id.dateTextCreateMileStone)),otec.getKod()  ));
			
		}
	}

	// VYTVORENI PREDMETU
	public void createSubjectHandler(View v) {
		createSubjectHandler(v, null, null, -1);
	}

	// Vytvoreni nebo editace PREDMETU
	public void createSubjectHandler(View v, String nazev, String kod,
			int kredity) {
		setContentView(R.layout.create_subject);
		ukazKlavesnici();
		EditText nazevOut = (EditText) findViewById(R.id.nazev_outCreateSubject);
		EditText kod_out = (EditText) findViewById(R.id.kod_outCreateSubject);
		EditText kredity_out = (EditText) findViewById(R.id.kredity_outCreateSubject);
		if (nazev != null)
			nazevOut.setText(nazev);
		
		if (kod != null){
			((Button) findViewById(R.id.createButtonCreateSubject)).setText(R.string.change);
			((TextView) findViewById(R.id.nadpisCreateSubject)).setText(R.string.edit_subject);
			kod_out.setFocusable(false);
			kod_out.setText(kod);
		}
		if (kredity != -1)
			kredity_out.setText(kredity+"");
		((Button) findViewById(R.id.createButtonCreateSubject))
				.setOnClickListener(new CreateTimeStoneListener(nazevOut,
						kod_out, kredity_out, Typ.PREDMET));
		
	}

	// VYTVORENI SEMESTRU
	public void createSemestrHandler(View v) {
		setContentView(R.layout.create_semester);
		ukazKlavesnici();

		

		// display the current date
		fillActualDate ();
		cil = R.id.stopDateCreateSemester;
		updateDisplay();
		cil = R.id.startDateCreateSemester;
		updateDisplay();

		((Button) findViewById(R.id.startDateButtonCreateSemester))
				.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						cil = R.id.startDateCreateSemester;
						showDialog(TIME_DIALOG_ID);
						showDialog(DATE_DIALOG_ID);
					}
				});
		((Button) findViewById(R.id.stopDateButtonCreateSemester))
				.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						cil = R.id.stopDateCreateSemester;
						showDialog(TIME_DIALOG_ID);
						showDialog(DATE_DIALOG_ID);
					}
				});
		
		EditText nazevOut = (EditText) findViewById(R.id.nazev_outCreateSemester);
		CheckBox sudost = (CheckBox) findViewById(R.id.sudostCreateSemester);

		TextView startOut = (TextView)  findViewById(R.id.startDateCreateSemester);
		TextView stopOut = (TextView)  findViewById(R.id.stopDateCreateSemester);
		
		((Button) findViewById(R.id.createButtonCreateSemester)).setOnClickListener(new CreateTimeStoneListener(nazevOut,
				sudost, startOut, stopOut, Typ.SEMESTR));
	}

	// ukaze klavesnici
	private void ukazKlavesnici() {
		InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		mgr.toggleSoftInput(0, 0);
	}

	// shodi klavesnici
	private void shodKlavesnici(View v) {
		InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		mgr.hideSoftInputFromWindow(v.getWindowToken(), 0);
	}

	// SRANDY S DIALOGAMA CAS A DATUM - predavat jinudy nez pres promenny
	// zakladni tridy se mi nepodarilo

	private void fillActualDate () {
		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);
		mHour = c.get(Calendar.HOUR_OF_DAY);
		mMinute = c.get(Calendar.MINUTE);
	}
	
	private void updateDisplay() {
		/*date = new Date();
		DateFormat dfm = new SimpleDateFormat("yyyyMMddHHmm");
		try {
			date = dfm.parse(""+mYear+mMonth+mDay+mHour+mMinute);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		((TextView) findViewById(cil)).setText(new StringBuilder()
				// Month is 0 based so add 1
				.append(pad(mHour)).append(":").append(pad(mMinute)).append(", ")
				.append(mDay).append(". ").append(mMonth + 1).append(" ")
				.append(mYear).append(" "));

	}
	
	// aby to nepsalo 16:8 ale 16:08
	private static String pad(int c) {
	    if (c >= 10)
	        return String.valueOf(c);
	    else
	        return "0" + String.valueOf(c);
	}
	static final int DATE_DIALOG_ID = 0;
	static final int TIME_DIALOG_ID = 1;
	static int cil;

	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;
	//private Date date;

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);

		case TIME_DIALOG_ID:
			return new TimePickerDialog(this, mTimeSetListener, mHour, mMinute,
					true);
		}
		return null;
	}

	// the callback received when the user "sets" the date in the dialog
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {

		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			// updateDisplay();
		}
	};

	// the callback received when the user "sets" the time in the dialog
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			mHour = hourOfDay;
			mMinute = minute;
			updateDisplay();
		}
	};

	// cotoje?
	public static String refreshTimeStones() {
		return "";
	}

	public TextView getTimeStoneText() {
		return timeStoneText;
	}

	public void setTimeStoneText(TextView timeStoneText) {
		this.timeStoneText = timeStoneText;
	}

	
	
	 boolean b = true;
	 public void tlacitko(int den1, int today, Date d, Calendar c, Button btn){
		 
		 
		 c.setTime(d);
		 int den = c.get(Calendar.DAY_OF_YEAR)-den1;
		 int datum = d.hashCode();
		 
		 btn.setId(datum);
		 btn.setX(den*35);
		 btn.setMinHeight(40);
		 btn.setMinWidth(80);
		 btn.setTextSize(24);
		 btn.setTextScaleX((float) 0.6);
		 btn.setPadding(0, 0, 0, 0);
		 btn.setLines(2);
		 
		if(b){			
		 	btn.setY(105);		 	
		 	String s = d.getDate()+"."+(d.getMonth()+1)+".\n |";
		 	btn.setText(s);
		 	 	
		b=false;
		 } else {
		
			 btn.setId(datum);
			 	btn.setY(135);
			 	btn.setLineSpacing(3, 1);
			 	String s = "|\n " + d.getDate()+"."+(d.getMonth()+1)+".";
			 	btn.setText(s);
			 	
		b=true;
		 }

		
		
		if(today-den1>den){
			btn.setTextColor(Color.rgb(139, 125, 107));	
		} else {
			
	    counter++;
		if(counter<4){
			btn.setTextColor(Color.rgb(255, 0, 0));
		} else {
			if(counter<7){
				btn.setTextColor(Color.rgb(255, 140, 0));
			} else {
				btn.setTextColor(Color.rgb(50, 205, 50));
			}
		}	
		}
		
		
	 	btn.setBackgroundColor(Color.TRANSPARENT);
	 }	
	 public static void merge(ArrayList<MileStone> vysledek, ArrayList<MileStone> arrayList) {
		 if ((vysledek!= null)&&(arrayList!=null))
			for (MileStone stone : arrayList) {
				vysledek.add(stone);
			}
		}
}