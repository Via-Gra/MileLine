package mileline.restclient;

public class Setup {

	private static final String APP_NAME = "milelinecz";
    private static final String BASIC_URL = "https://" + APP_NAME + ".appspot.com/";
    public static final String ALLTIMESTONES = BASIC_URL + "timeStone";
    public static final String TIMESTONEBYKOD = BASIC_URL + "timeStone?kod=";
    public static final String MILESTONESBYTIMESTONE = BASIC_URL + "mileStone?kod=";
    
    
    //https://milelinecz.appspot.com/timeStone?name=Internetove%20Aplikace&kod=VIA&kredity=3
    
    
    public static final String TIMESTONEURL = BASIC_URL + "timeStone";
    public static final String TIMESTONETYPPAR = "?typ=";
    public static final String TIMESTONNAMEPAR = "?nazev=";
    public static final String TIMESTONEKODPAR = "&kod=";
    public static final String TIMESTONEKREDITYPAR = "&kredity=";
    public static final String TIMESTONETYPEPAR = "&typ=";
    
    public static final String TIMESTONEZACATEKPAR = "&zacatek=";   
    public static final String TIMESTONEKONECPAR = "&konec=";
    public static final String TIMESTONESUDOSTPAR = "&sudost=";
    
    public static final String MILESTONEURL = BASIC_URL + "mileStone";
    public static final String MILESTONENAZEVKPAR = "?nazev=";   
    public static final String MILESTONEDATUMPAR = "&datum=";
    public static final String MILESTONEPOZNAMKAPAR = "&poznamka=";
	
}
