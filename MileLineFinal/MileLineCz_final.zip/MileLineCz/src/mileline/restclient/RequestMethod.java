package mileline.restclient;

public enum RequestMethod {
	GET,POST;
}
