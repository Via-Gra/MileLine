package mileline.restclient;

import mileline.model.TimeStone;
import mileline.model.Typ;

public class MileLineURLCreator {

	/**Vytvori url pro ziskani vsech timestonu ze serveru.
	 * 
	 * @return URL to get all timeStones at once
	 */
	public static String getAllTimeStonesURL(){
		return substitudeSpace(Setup.ALLTIMESTONES);
	}
	/**Vytvori url pro ziskani vsech timestonu dle typu ze serveru.
	 * 
	 * @return URL to get all timeStones at once
	 */
	public static String getAllTimeStonesURL(Typ typ){
		if (typ == null) return getAllTimeStonesURL();
		return substitudeSpace(Setup.ALLTIMESTONES+Setup.TIMESTONETYPPAR+typ.toString());
	}
	
	/**Vytvori url pro ziskani timestonu pomoci jeho id.
	 * 
	 * @param id id key
	 * @return URL pro ziskani timestonu pomoci jeho id.
	 */
	public static String getTimeStoneByIdURL(String id){
		return substitudeSpace(Setup.TIMESTONEBYKOD + id);
	}

	/**Vraci url pro nacteni vsech milestonů, ktere jsou na serveru v timestonu.
	 * 
	 * @param stone 
	 * @return URL pro nacteni mileStonů
	 */
	public static String getAllMileStonesByTimeStone(TimeStone stone){
		return substitudeSpace(Setup.MILESTONESBYTIMESTONE + stone.getKod());
	}
	
	/**
	 * Vytvori url pro vytvoreni libovolneho timestonu na serveru.
	 * 
	 * @param name
	 * @param kod
	 * @param kredity
	 * @param typ
	 * @return
	 */
	/*public static String createTimeStoneUrl(String name,String kod,String kredity,String typ){
		return Setup.TIMESTONEURL + Setup.TIMESTONNAMEPAR + name + Setup.TIMESTONEBYKOD + kod + Setup.TIMESTONEKREDITYPAR + kredity + Setup.TIMESTONETYPEPAR + typ;
	}*/
	
	/**
	 * Vytvori url pro vytvoreni timestonu typu SEMESTR na serveru.
	 * 
	 * @param name
	 * @param kod
	 * @param kredity
	 * @return
	 */
	public static String createSemestrUrl(String name,Long start, Long stop, Boolean sudost){
		return substitudeSpace(Setup.TIMESTONEURL + Setup.TIMESTONNAMEPAR + name + Setup.TIMESTONEZACATEKPAR + start + Setup.TIMESTONEKONECPAR + stop + Setup.TIMESTONESUDOSTPAR + sudost + Setup.TIMESTONETYPEPAR + "SEMESTR");
	}
	
	/**
	 * Vytvori url pro vytvoreni timestonu typu PREDMET na serveru.
	 * 
	 * @param name
	 * @param kod
	 * @param kredity
	 * @return
	 */
	public static String createSubjectUrl(String name,String kod,String kredity){
		return substitudeSpace(Setup.TIMESTONEURL + Setup.TIMESTONNAMEPAR + name + Setup.TIMESTONEKODPAR + kod + Setup.TIMESTONEKREDITYPAR + kredity + Setup.TIMESTONETYPEPAR + "PREDMET");
	}
	
	
	public static String createMileStone(String name, String poznamka,
			Long datum, String kod) {
		return substitudeSpace(Setup.MILESTONEURL+Setup.MILESTONENAZEVKPAR+name+Setup.MILESTONEPOZNAMKAPAR+poznamka+Setup.MILESTONEDATUMPAR+datum+Setup.TIMESTONEKODPAR+kod);
	}
	
	public static String getAllMileStonesURL() {
		return substitudeSpace(Setup.MILESTONEURL);
	}
	
	public static String substitudeSpace (String string){
		String vysledek = "";
		for (int a = 0; a< string.length();a++){
			if (string.charAt(a) == ' ') vysledek+="%20";
			else if (string.charAt(a) == '\n') vysledek+="%20";
			else vysledek+=string.charAt(a);
		}
		return vysledek;
		
	}
	
}
