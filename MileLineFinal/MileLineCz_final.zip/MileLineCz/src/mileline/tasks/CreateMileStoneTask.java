package mileline.tasks;

import java.net.URL;

import mileline.restclient.RequestMethod;
import mileline.restclient.RestClient;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.EditText;
import android.widget.Toast;

public class CreateMileStoneTask extends AsyncTask<URL, String, String>{
	public Context appContext;
	private ProgressDialog dialog;
//	private EditText namev,poznamkav;
	
	public CreateMileStoneTask(EditText namev, EditText poznamkav) {
	/*	this.namev = namev;
		this.poznamkav = poznamkav;*/
	}

	@Override
	protected void onPreExecute() {
		this.dialog = ProgressDialog.show(appContext, "",
				"Creating TimeStones...");
	}
	
	@Override
	protected String doInBackground(URL... params) {
		String responseString = null;

		String baseurlString = params[0].toString();

		RestClient client = new RestClient(baseurlString);
		
		try {
			client.Execute(RequestMethod.POST);
		} catch (Exception e) {
			e.printStackTrace();
		}

		responseString = client.getResponse();
		return responseString;
	}
	
	@Override
	protected void onPostExecute(String result) {
		this.dialog.cancel();
		
		//vytvorit hlasku "USPECH"
		Toast.makeText(appContext,result,Toast.LENGTH_SHORT).show();
	}

}
