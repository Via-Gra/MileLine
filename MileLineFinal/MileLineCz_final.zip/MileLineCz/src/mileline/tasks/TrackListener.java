package mileline.tasks;

import java.util.ArrayList;

import mileline.diskmanager.HardFile;
import mileline.model.TimeStone;
import mileline.views.R;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class TrackListener implements OnClickListener{
	TimeStone timestone;
	Button trackingButton,createMileStoneButton;
 TextView textView;


	public TrackListener(TimeStone timestone, Button trackingButton, TextView textView, Button createMileStoneButton) {
	super();
	this.timestone = timestone;
	this.trackingButton = trackingButton;
	this.textView = textView;
	this.createMileStoneButton = createMileStoneButton;
}


	@Override
	public void onClick(View v) {
		HardFile hf = new HardFile("track"+timestone.getTyp().toString());
		ArrayList<TimeStone> tsArray = (ArrayList<TimeStone>) hf
				.loadDataArray();
		boolean contains = false;
		for (TimeStone ts : tsArray) {
			if (ts.getKod().equals(timestone.getKod())) {
				timestone = ts;
				contains = true;
				break;
			}
		}
		if (!contains) {
			tsArray.add(timestone);
					trackingButton.setText(R.string.stop_track);
					textView.setText((R.string.zapsany));
					createMileStoneButton.setVisibility(View.VISIBLE);
			hf.saveDataArray(tsArray);
		} else {
			tsArray.remove(timestone);
					trackingButton.setText(R.string.start_track);
					textView.setText(R.string.nezapsany);
					createMileStoneButton.setVisibility(View.GONE);
			hf.saveDataArray(tsArray);
		}

	}
}
