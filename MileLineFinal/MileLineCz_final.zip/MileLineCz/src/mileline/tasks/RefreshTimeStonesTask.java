package mileline.tasks;

import java.lang.reflect.Type;
import java.net.URL;
import java.util.ArrayList;

import mileline.diskmanager.HardFile;
import mileline.model.TimeStone;
import mileline.model.Typ;
import mileline.restclient.RequestMethod;
import mileline.restclient.RestClient;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class RefreshTimeStonesTask extends AsyncTask<URL, String, String> {

	public Context appContext;
	private ProgressDialog dialog;
	private ListView seznamStonu;
	private Gson gson = new Gson();

	private Button butt;
	private Typ typ;

	public RefreshTimeStonesTask(Button butt, ListView seznamStonu, Typ typ) {
		super();
		this.butt = butt;
		this.seznamStonu = seznamStonu;
		this.typ = typ;
	}

	@Override
	protected void onPreExecute() {
		this.dialog = ProgressDialog.show(appContext, "",
				"Refreshing TimeStones...");
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void onPostExecute(String result) {
		this.dialog.cancel();
		HardFile hf = new HardFile("all" + typ.toString());

		Type collectionType = new TypeToken<ArrayList<TimeStone>>() {
		}.getType();
		ArrayList<TimeStone> timeStones = (ArrayList<TimeStone>) gson.fromJson(
				result, collectionType);

		hf.saveDataArray(timeStones);

		hf = new HardFile("track" + typ.toString());
		ArrayList<TimeStone> myStones = (ArrayList<TimeStone>) hf
				.loadDataArray();
		seznamStonu.setAdapter(new SeznamTimeStonuAdapter(appContext,
				timeStones, myStones));

		butt.setEnabled(true);
	}

	@Override
	protected String doInBackground(URL... params) {
		String responseString = null;

		String baseurlString = params[0].toString();

		RestClient client = new RestClient(baseurlString);

		try {
			client.Execute(RequestMethod.GET);
		} catch (Exception e) {
			e.printStackTrace();
		}

		responseString = client.getResponse();

		return responseString;
	}

}
