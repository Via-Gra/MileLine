package mileline.tasks;

import java.net.MalformedURLException;
import java.net.URL;

import mileline.restclient.MileLineURLCreator;
import mileline.views.MileLineCzActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;

public class RefreshMileStoneListener implements OnClickListener {
	Button refreshButt;
	ListView seznamStonu;
	public RefreshMileStoneListener(Button refreshButt, ListView seznamStonu) {
		this.refreshButt=refreshButt;
		this.seznamStonu=seznamStonu;
	}

	@Override
	public void onClick(View v) {
		String url = MileLineURLCreator.getAllMileStonesURL();
		// refreshButt.setEnabled(false);
		RefreshMileStonesTask task = new RefreshMileStonesTask(refreshButt,seznamStonu);
		task.appContext = MileLineCzActivity.getSelf();
		try {
			task.execute(new URL(url));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

}
