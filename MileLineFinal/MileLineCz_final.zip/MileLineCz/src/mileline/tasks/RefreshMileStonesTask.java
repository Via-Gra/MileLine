package mileline.tasks;

import java.lang.reflect.Type;
import java.net.URL;
import java.util.ArrayList;

import mileline.diskmanager.HardFile;
import mileline.model.MileStone;
import mileline.model.TimeStone;
import mileline.model.Typ;
import mileline.restclient.RequestMethod;
import mileline.restclient.RestClient;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class RefreshMileStonesTask extends AsyncTask<URL, String, String> {
	private Gson gson;
	public Context appContext;
	Button refreshButt;
	ListView seznamStonu;

	public RefreshMileStonesTask(Button refreshButt, ListView seznamStonu) {
		this.gson = new Gson();
		this.refreshButt = refreshButt;
		this.seznamStonu = seznamStonu;
	}

	@Override
	protected String doInBackground(URL... arg0) {
		String responseString = null;

		String baseurlString = arg0[0].toString();

		RestClient client = new RestClient(baseurlString);

		try {
			client.Execute(RequestMethod.GET);
		} catch (Exception e) {
			e.printStackTrace();
		}

		responseString = client.getResponse();
		return responseString;
	}

	@Override
	protected void onPostExecute(String result) {
		Type collectionType = new TypeToken<ArrayList<MileStone>>() {
		}.getType();
		ArrayList<MileStone> mileStones = (ArrayList<MileStone>) gson.fromJson(
				result, collectionType);

		
	/*	Toast.makeText(
				MileLineCzActivity.getSelf().getApplicationContext(),
				mileStones.get(7).toString(),
				Toast.LENGTH_SHORT).show();*/
		
		// ULOZENI MILESTONES
		ArrayList<TimeStone> timeStones = new ArrayList<TimeStone>();
		HardFile hf = new HardFile("track" + Typ.PREDMET);
		ArrayList<TimeStone> predmety = (ArrayList<TimeStone>) hf
				.loadDataArray();
		for (TimeStone predmet : predmety) {
		predmet.getMileStony().clear();
			for (MileStone milestone : mileStones) {
			 if ((milestone.getTimeStone()!=null)&&(predmet.getKod().equals(milestone.getTimeStone().getKod())))
					predmet.addMileStone(milestone);
			if (predmet.getKod().equals(predmety.get(0).getKod())) predmety.get(0).addMileStone(milestone);//pro pripad, ze to nerozlisi
			}
		}
		merge (timeStones, predmety);
		hf.saveDataArray(predmety);
		
		hf = new HardFile("track" + Typ.SEMESTR);
		ArrayList<TimeStone> semestry = (ArrayList<TimeStone>) hf
				.loadDataArray();
		for (TimeStone semestr : semestry) {
			semestr.getMileStony().clear();
				for (MileStone milestone : mileStones) {
					if ((milestone.getTimeStone()!=null)&&(semestr.getKod().equals(milestone.getTimeStone().getKod())))
						semestr.addMileStone(milestone);
				}
			}

merge (timeStones, semestry);
hf.saveDataArray(semestry);


		seznamStonu.setAdapter(new SeznamMileStonuAdapter(appContext,
				timeStones));
		
	}
	
	public static void merge(ArrayList<TimeStone> array, ArrayList<TimeStone> second) {
		for (TimeStone stone : second) {
			array.add(stone);
		}
	}

}
