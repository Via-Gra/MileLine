package mileline.tasks;

import java.net.MalformedURLException;
import java.net.URL;

import mileline.model.Typ;
import mileline.restclient.MileLineURLCreator;
import mileline.views.MileLineCzActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;

public class RefreshTimeStoneListener implements OnClickListener{
	Button button;
	ListView seznamMileStonu;
	Typ typ;
	
	public RefreshTimeStoneListener(Button button, ListView seznamMileStonu, Typ typ) {
		super();
		this.button = button;
		this.seznamMileStonu = seznamMileStonu;
		this.typ = typ;
		button.setEnabled(true);
	}

	@Override
	public void onClick(View v) {
		
		String url = MileLineURLCreator.getAllTimeStonesURL(typ);
		button.setEnabled(false);	
		RefreshTimeStonesTask task = new RefreshTimeStonesTask(button, seznamMileStonu,typ);
		task.appContext = MileLineCzActivity.getSelf();
		try {
			task.execute(new URL(url));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}
}