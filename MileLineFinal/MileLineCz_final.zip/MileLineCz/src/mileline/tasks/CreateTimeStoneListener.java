package mileline.tasks;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import mileline.model.Typ;
import mileline.restclient.MileLineURLCreator;
import mileline.views.MileLineCzActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CreateTimeStoneListener implements OnClickListener{
	private String name,kod,kredity,typ;
	private EditText namev,kodv,kredityv;
	private CheckBox checkbockv;
	private TextView startv,stopv;
	private Long start,stop;
	private boolean sudost;
	
	
	
	public CreateTimeStoneListener(EditText namev, EditText kodv,
			EditText kredityv, Typ typ) {
		super();
		this.namev = namev;
		this.kodv = kodv;
		this.kredityv = kredityv;
		this.typ = typ.toString();
		//Toast.makeText(MileLineCzActivity.getSelf().getApplicationContext(),name,Toast.LENGTH_SHORT).show();
	}


	public CreateTimeStoneListener(EditText nazevOut, CheckBox sudostBox,
			TextView start, TextView stop, Typ typ) {
		namev = nazevOut;
		Toast.makeText(
				MileLineCzActivity.getSelf().getApplicationContext(),
				nazevOut.getText(),
				Toast.LENGTH_SHORT).show();
		checkbockv = sudostBox;
		startv = start;
		stopv = stop;
		this.typ = typ.toString();
	}


	@Override
	public void onClick(View v) {
		
		if (typ.equals(Typ.PREDMET.toString())){
			name = namev.getText().toString();
			kod = kodv.getText().toString();
			kredity = kredityv.getText().toString();
			
		String url = MileLineURLCreator.createSubjectUrl(name, kod, kredity);
		
		CreateTimeStoneTask task = new CreateTimeStoneTask(namev, kodv, kredityv);
		task.appContext = MileLineCzActivity.getSelf();
		try {
			task.execute(new URL(url));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		} else if (typ.equals(Typ.SEMESTR.toString())){
			name = namev.getText().toString();
			sudost = checkbockv.isChecked();
			DateFormat dfm = new SimpleDateFormat("HH:mm, dd. MM yyyy");		

			try {
				start = (dfm.parse(startv.getText().toString() )).getTime();
				stop = (dfm.parse(stopv.getText().toString() )).getTime() ;
				} catch (ParseException e) {
					e.printStackTrace();
				}
			
			String url = MileLineURLCreator.createSemestrUrl(name, start, stop, sudost);
			/*Toast.makeText(
					MileLineCzActivity.getSelf().getApplicationContext(),
					url,
					Toast.LENGTH_SHORT).show();*/
			CreateTimeStoneTask task = new CreateTimeStoneTask(namev, null, null);
			task.appContext = MileLineCzActivity.getSelf();
			try {
				task.execute(new URL(url));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}

}
