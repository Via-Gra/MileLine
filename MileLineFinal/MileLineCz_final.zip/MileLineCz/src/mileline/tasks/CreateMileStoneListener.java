package mileline.tasks;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import mileline.restclient.MileLineURLCreator;
import mileline.views.MileLineCzActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CreateMileStoneListener implements OnClickListener {
	private EditText namev, poznamkav;
	private TextView datumv;
	private String name, poznamka,kod;
	private Long datum;

	public CreateMileStoneListener(EditText namev, EditText poznamkav,TextView datumv, String kod) {
		super();
		this.namev = namev;
		this.poznamkav = poznamkav;
		this.datumv = datumv;
		this.kod = kod;
	}

	@Override
	public void onClick(View v) {

		name = namev.getText().toString();
		poznamka = poznamkav.getText().toString();
		DateFormat dfm = new SimpleDateFormat("HH:mm, dd. MM yyyy");
		try {
			datum = (dfm.parse(datumv.getText().toString())).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		String url = MileLineURLCreator.createMileStone(name, poznamka, datum,kod);
		/*
		 Toast.makeText( MileLineCzActivity.getSelf().getApplicationContext(),
		 url, Toast.LENGTH_SHORT).show();
		 */
		CreateMileStoneTask task = new CreateMileStoneTask(namev, poznamkav);
		task.appContext = MileLineCzActivity.getSelf();
		try {
			task.execute(new URL(url));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

}
