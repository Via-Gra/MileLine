package mileline.tasks;

import java.util.ArrayList;

import mileline.model.MileStone;
import mileline.model.TimeStone;
import mileline.model.ViewHolderTimeStonu;
import mileline.views.MileLineCzActivity;
import mileline.views.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SeznamTimeStonuAdapter extends BaseAdapter {
	private static ArrayList<TimeStone> searchArrayList;
	private static ArrayList<TimeStone> myStones;

	private LayoutInflater mInflater;

	public static ArrayList<TimeStone> sortByName(ArrayList<TimeStone> list) {
		ArrayList<TimeStone> vysledek = new ArrayList<TimeStone>();
		TimeStone nejmensi = null;

		do {
			for (TimeStone stone : list) {
				if (nejmensi == null
						|| isSecondSmaller(nejmensi.getNazev().toLowerCase(),
								stone.getNazev().toLowerCase())) {
					nejmensi = stone;
				}
			}
			if (nejmensi == null)
				break;
			vysledek.add(nejmensi);
			list.remove(nejmensi);
			nejmensi = null;

		} while (!list.isEmpty());
		return vysledek;
	}

	private static boolean isSecondSmaller(String first, String second) {
		if (first.length() == 0)
			return false;
		if (second.length() == 0)
			return true;
		if (first.charAt(0) > second.charAt(0))
			return true;
		if (first.charAt(0) == second.charAt(0))
			return isSecondSmaller(first.substring(1), second.substring(1));
		return false;
	}

	public SeznamTimeStonuAdapter(Context context,
			ArrayList<TimeStone> results, ArrayList<TimeStone> myStones) {
		searchArrayList = sortByName(results);
		this.myStones = myStones;
		mInflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return searchArrayList.size();
	}

	public Object getItem(int position) {
		return searchArrayList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolderTimeStonu holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.timestone_list, null);
			holder = new ViewHolderTimeStonu();
			holder.nazev = (TextView) convertView.findViewById(R.id.nazevTimeStoneList);
			holder.kod = (TextView) convertView.findViewById(R.id.kodTimeStoneList);
			holder.typ = (TextView) convertView.findViewById(R.id.typTimeStoneList);
			holder.mile = (TextView) convertView.findViewById(R.id.mileTimeStoneList);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolderTimeStonu) convertView.getTag();
		}
		holder.object = searchArrayList.get(position);
		holder.nazev.setText(searchArrayList.get(position).getNazev());
		if ((myStones != null)&& (contains (myStones,searchArrayList.get(position)))) holder.nazev.setTextColor(MileLineCzActivity.getSelf().getResources().getColor(R.color.lessShinyHeader));
		holder.kod.setText(searchArrayList.get(position).getKod());
		holder.typ.setText(searchArrayList.get(position).getTyp()
				.toString());
//		holder.mile.setText(searchArrayList.get(position).getMileStony().get(0).getNazev());

		return convertView;
	}

	public boolean contains(ArrayList<TimeStone> array, TimeStone timestone) {
		for (TimeStone stone : array) {
			if (stone.getKod().equals(timestone.getKod()))
				return true;
		}
		return false;
	}
}
