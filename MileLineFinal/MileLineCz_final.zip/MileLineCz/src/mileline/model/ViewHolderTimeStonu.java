package mileline.model;

import android.widget.TextView;

public class ViewHolderTimeStonu {
	public TextView nazev;
	public TextView kod;
	public TextView typ;
	public TextView mile;
	public Object object;
	public boolean isMy =false;
}
