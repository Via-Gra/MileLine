package mileline.model;

import android.widget.TextView;

public class ViewHolderMileStonu {
	public TextView nazev;
	public TextView datum;
	public TextView predmet;
	public Object object;
}
