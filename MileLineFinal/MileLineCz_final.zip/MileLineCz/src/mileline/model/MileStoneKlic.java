package mileline.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class MileStoneKlic implements Serializable{
	private String kind;
	private int id;
	private String name;
	private TimeStoneKlic parentKey;
	
	public MileStoneKlic(String kind, int id, String name,
			TimeStoneKlic parentKey) {
		super();
		this.kind = kind;
		this.id = id;
		this.name = name;
		this.parentKey = parentKey;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TimeStoneKlic getParentKey() {
		return parentKey;
	}

	public void setParentKey(TimeStoneKlic parentKey) {
		this.parentKey = parentKey;
	}
	
	
}
