package mileline.model;

import java.io.Serializable;

public enum Typ implements Serializable { 
PREDMET,SEMESTR
}

